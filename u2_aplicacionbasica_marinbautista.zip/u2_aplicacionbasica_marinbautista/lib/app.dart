import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:flutter/material.dart';
enum SingingCharacter { Dean, Sam, Castiel, Bobby }
class app extends StatefulWidget {
  const app({Key? key}) : super(key: key);

  @override
  State<app> createState() => _appState();
}

class _appState extends State<app> {
  bool dark = false;
  List<bool> _values = List.generate(6, (_) => false);
  int _calificacion = 0;
  String name="";
  SingingCharacter? _character = SingingCharacter.Dean;
  final Q1 = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Lieblings TV-Show"),
        actions: [
       //   Switch(value: AdaptiveTheme.of(context).mode
        //      == AdaptiveThemeMode.light,
       //       onChanged: (bool value){
       //     if(value){
       //       AdaptiveTheme.of(context).setLight();
       //     }
       //     else{
        //      AdaptiveTheme.of(context).setDark();
         //   }
         //     }),
          
          IconButton(onPressed: (){
          setState(() {
            dark=!dark;
            if(dark){
              AdaptiveTheme.of(context).setDark();
            }
            else
              {
                AdaptiveTheme.of(context).setLight();
              }
          });
      }, icon: Icon(dark ? Icons.light_mode : Icons.dark_mode),),
       ],

      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(padding: EdgeInsets.all(20)),
            SizedBox(
              child: Image.asset('assets/SPN.jpg', width: 200,),
            ),
            SizedBox(height: 20,),
            Row(
                mainAxisAlignment: MainAxisAlignment.center,
              children:[
                IconButton(
                  onPressed: () {
                      setState(() {
                        _values[1]=!_values[1];
                        if(_values[1]==false){
                          _calificacion =0;
                          _values[5]=false;
                          _values[2]=false;
                          _values[3]=false;
                          _values[4]=false;
                        }else{
                          _calificacion =20;
                        }

                      });
                  },
                  icon: Icon(_values[1] ? Icons.favorite:Icons.favorite_border),),

                IconButton(
                  onPressed: () {
                    setState(() {
                      _values[2]=!_values[2];
                      if(_values[2]==false){
                        _calificacion =20;
                        _values[5]=false;
                        _values[3]=false;
                        _values[4]=false;
                      }else{
                        _calificacion =40;
                        _values[1]=true;
                      }

                    });
                  },
                  icon: Icon(_values[2] ? Icons.favorite:Icons.favorite_border),),
                IconButton(
                  onPressed: () {
                    setState(() {
                      _values[3]=!_values[3];
                      if(_values[3]==false){
                        _calificacion =40;
                        _values[5]=false;
                        _values[4]=false;
                      }else{
                        _calificacion =60;
                        _values[1]=true;
                        _values[2]=true;
                      }

                    });
                  },
                  icon: Icon(_values[3] ? Icons.favorite:Icons.favorite_border),),
                IconButton(
                  onPressed: () {
                    setState(() {
                      _values[4]=!_values[4];
                      if(_values[4]==false){
                        _calificacion =60;
                        _values[5]=false;
                      }else{
                        _calificacion =80;
                        _values[1]=true;
                        _values[2]=true;
                        _values[3]=true;
                      }

                    });
                  },
                  icon: Icon(_values[4] ? Icons.favorite:Icons.favorite_border),),
                IconButton(
                  onPressed: () {
                    setState(() {
                      _values[5]=!_values[5];
                      if(_values[5]==false){
                        _values[5]=!_values[5];
                        _calificacion =80;
                      }else{
                        _calificacion =100;
                        _values[1]=true;
                        _values[2]=true;
                        _values[3]=true;
                        _values[4]=true;
                      }

                    });
                  },
                  icon: Icon(_values[5] ? Icons.favorite:Icons.favorite_border),),
    ]

            ),
            SizedBox(height: 10,),
            Text('Calificación: $_calificacion'),
            SizedBox(height: 30,),
            Text('Personaje favorito:'),

                ListTile(
                  title: const Text('Dean Winchester'),
                  leading: Radio<SingingCharacter>(
                    value: SingingCharacter.Dean,
                    groupValue: _character,
                    onChanged: (SingingCharacter? value) {
                      setState(() {
                        _character = value;
                        name=SingingCharacter.Dean.name;
                        ScaffoldMessenger.of(context)
                            .showSnackBar(SnackBar(content: Text("Dean tambien es mi personaje favorito")));
                      });
                    },
                  ),
                ),
                ListTile(
                  title: const Text('Sam Winchester'),
                  leading: Radio<SingingCharacter>(
                    value: SingingCharacter.Sam,
                    groupValue: _character,
                    onChanged: (SingingCharacter? value) {
                      setState(() {
                        _character = value;
                        name=SingingCharacter.Sam.name;
                        ScaffoldMessenger.of(context)
                            .showSnackBar(SnackBar(content: Text("Sam tambien es mi personaje favorito")));
                      });
                    },
                  ),
                ),
                ListTile(
                  title: const Text('Castiel'),
                  leading: Radio<SingingCharacter>(
                    value: SingingCharacter.Castiel,
                    groupValue: _character,
                    onChanged: (SingingCharacter? value) {
                      setState(() {
                        _character = value;
                        name=SingingCharacter.Castiel.name;
                        ScaffoldMessenger.of(context)
                            .showSnackBar(SnackBar(content: Text("Castiel tambien es mi personaje favorito")));
                      });
                    },
                  ),
                ),
                ListTile(
                  title: const Text('Bobby Singler'),
                  leading: Radio<SingingCharacter>(
                    value: SingingCharacter.Bobby,
                    groupValue: _character,
                    onChanged: (SingingCharacter? value) {
                      setState(() {
                        _character = value;
                        name=SingingCharacter.Bobby.name;
                      });
                    },
                  ),
                ),
        SizedBox(
          width: 300,
          height: 100,
          child:
          TextField(controller: Q1,
            decoration: InputDecoration(
                labelText: "¿Quién es el rey del infierno?",
                border: UnderlineInputBorder(),
                contentPadding: EdgeInsets.symmetric(vertical: 15, horizontal: 10)),
          ),
        ),
            ElevatedButton.icon(onPressed: (){
              mensaje();
            }, label: Text("Registrar"), icon: Icon(Icons.save_sharp),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.indigo, // Establecer el color de fondo del botón
                )),
            SizedBox(height: 20,),
          ],
        ),
      ),
    );

  }

  void mensaje() {
    showDialog(context: context,
        builder: (BuildContext context){
          return AlertDialog(
            title: Text("Guardar"),
            content: Text("Personaje fav: ${name} \n"
                "Calificacion: ${_calificacion} \n"
                "Rey del infierno: ${Q1.text}") ,
            actions: [
              TextButton(onPressed: (){
                Navigator.of(context).pop();
              },
                  child: Text("Ok"))
            ],
          ); //AlertDialog
        }); //showDialog
  }
}
