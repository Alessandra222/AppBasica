package mx.edu.ittepic.u2_aplicacionbasica_marinbautista

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
